﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace A6409001_WebPD_Week2.Models
{
    public class Frind
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string City { get; set; }

    }
}