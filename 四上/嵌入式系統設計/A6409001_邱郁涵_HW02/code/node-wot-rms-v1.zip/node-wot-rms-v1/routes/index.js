// 載入express模組 
var express = require('express');
// 使用express.Router類別建構子來建立路由物件
var router = express.Router();

// 取得並列出Server端的ip，需在專案中安裝underscore模組: npm install underscore --save
var sip = require('underscore').chain(require('os').networkInterfaces()).values()
    .flatten().find({family: 'IPv4', internal: false}).value().address;
console.log('Server IP='+sip);

// 建立Web Video Streaming的狀態儲存檔wvs_status.txt(初始值為off)
fs = require('fs');
fs.writeFileSync('./wvs-status.txt', 'off');
console.log('The wvs-status.txt is created!');

// 建立Web Video Streaming的pid儲存檔wvs_pid.txt(初始值為0)
fs.writeFileSync('./wvs-pid.txt', '0');
console.log('The wvs-pid.txt is created!');

//=================== 回傳網頁段落 ========================================//
//========= 根據Client端利用GET送來之不同路由，回傳相對應的網頁 =============//
//=======================================================================//
// 回傳給Client端首頁及該網頁之標題
router.get('/', function(req, res) {
	res.render('index.ejs', {title:"專案首頁"});
});

// 顯示Web遠程監控操作介面
router.get('/webremotecontrol', function(req, res) {

	// 讓遠端監控網頁載入時，就顯示影像串流
	// 讀取Web Video Streaming的狀態
	fs=require('fs');
    wvs_status = fs.readFileSync('./wvs-status.txt','utf8'); 
	
    // 若影像串流關閉著，則啟動影像串流
	if(wvs_status=='off')
	{
		exec = require('child_process').exec;
		web_vs = exec('python3 ./web-vs-server.py', shell=false);
		wvs_pid = web_vs.pid+1;
		console.log('The current wvs_pid: ' + wvs_pid);
		
		// 將pid of Web Video Streaming存入檔案中
		fs = require('fs');
		fs.writeFileSync('./wvs-pid.txt', wvs_pid); 
		
		// 將on存入Web Video Streaming的狀態檔中
		fs = require('fs');
		fs.writeFileSync('./wvs-status.txt', 'on'); 
		console.log('The pid and status of web video streaming is saved!');
	}
	// 然後顯示遠端監控網頁
	res.render('webremotecontrol.ejs', {title:"Web遠程監控操作網頁"});
});

//=================== 以下為REST網路服務段落 ==================================//
//==++== 根據Client端利用GET或POST送來之不同路由，執行相對應之服務方法 ===++=====//
//===================================================================+++====//

//********************** 儲存Email清單之服務方法 *********************************
//***** 客戶端提出  POST /store_email/:email 請求時，執行此服務方法(匿名式函數) *****
router.post('/store_email/:email', function(req, res){
	email=req.params.email;
	emails="hungmh1@gmail.com" + " " + email; //預設第1個為我的Gmail帳號
	// 將emails清單字串存alert_emails.txt中
	fs = require('fs');
	fs.writeFileSync('./alert-emails.txt', emails);
	//	
	message = {"message": emails};
	console.log("The email accounts to receive alerts: " + message.message);
	res.send(message);
});

//******************** 啟動與關閉即時網頁視訊串流之服務方法 *****************************
//***** 客戶端提出 POST /web_video_streaming/:cmd 請求時，執行此服務方法(匿名式函數) *****
router.post('/web_video_streaming/:cmd', function(req, res){
	cmd=req.params.cmd;
	if(cmd=='on')
	{
		// 讀取Web Video Streaming的狀態
		fs=require('fs');
		wvs_status = fs.readFileSync('./wvs-status.txt','utf8'); 
		
		//
		if(wvs_status=='off')
		{
			exec = require('child_process').exec;
			web_vs = exec('python3 ./web-vs-server.py', shell=false);
			wvs_pid = web_vs.pid+1;
			console.log('The current wvs_pid: '+ wvs_pid);
			
			// 將pid of Web Video Streaming存入檔案中
			fs = require('fs');
			fs.writeFileSync('./wvs-pid.txt', wvs_pid); 
			
			// 將on存入Web Video Streaming的狀態檔中
			fs = require('fs');
			fs.writeFileSync('./wvs-status.txt', 'on'); 
			console.log('The pid and status of web video streaming is saved!');
		}
		// 回傳訊息給網頁端
		message={'message':'網頁即時影像串流已經開啟!'};
		res.set({
			'charset': 'utf-8'  // 設定回傳結果之編碼為utf-8，網頁端才能正常顯示中文
		});
		res.send(message);
	}
  
	if(cmd=='off') 
	{
		// 讀取Web Video Streaming的狀態
		fs=require('fs');
		wvs_status=fs.readFileSync('./wvs-status.txt','utf8');
		
		//
		if(wvs_status=='on')
		{
			// 讀取pid of Web Video Streaming
			fs=require('fs');
			wvs_pid=fs.readFileSync('./wvs-pid.txt','utf8');
			
			// 透過pid關閉(殺掉)Web Video Streaming
			exec = require('child_process').exec;
			exec('sudo kill ' + wvs_pid);
			console.log('The wvs process of ' + wvs_pid + ' is killed!');
			
			// 將off存入Web Video Streaming的狀態檔中
			fs = require('fs');
			fs.writeFileSync('./wvs-status.txt', 'off');
		}
			
		// 回傳訊息給網頁端
		message={'message':'網頁即時影像串流已經關閉!'};
		res.set({
			'charset': 'utf-8'  // 設定回傳結果之編碼為utf-8，網頁端才能正常顯示中文
		});
		res.send(message);
	}
});

//********************** 拍攝照片之服務方法 *********************************
//***** 客戶端提出  POST /take_picture 請求時，執行此服務方法(匿名式函數) *****
router.post('/take_picture', function(req, res){
  
	// 讀取Web Video Streaming的狀態
	fs=require('fs');
	wvs_status=fs.readFileSync('./wvs-status.txt','utf8');
	
	// 若影像串流開著，先把它關掉
	if(wvs_status=='on')
	{
		// 讀取pid of Web Video Streaming
		fs=require('fs');
		wvs_pid=fs.readFileSync('./wvs-pid.txt','utf8');
		
		// 透過pid關閉(殺掉)Web Video Streaming
		exec = require('child_process').exec;
		exec('sudo kill ' + wvs_pid);
		console.log('The wvs process of ' + wvs_pid + ' is killed!');
		// 將off存入Web Video Streaming的狀態檔中
		fs = require('fs');
		fs.writeFileSync('./wvs-status.txt', 'off');
	}
	
	// 建立日期時間字串
	dateformat=require('dateformat'); //匯入dateformat模組
	datestring = dateformat(Date().toString(), "yyyy-mm-dd_HH:MM:ss"); //產生格式如2016-12-04_21:17:58之日期字串
	//以時間戳記當作檔名的一部分，使檔名具有唯一性
	picture_name = 'img' + datestring + '.jpg'; 
	// 開始拍照 (用同步方式進行，以確保在傳送Email之前就有照片了)
	execSync = require('child_process').execSync;
	// 命令解讀： 攝像頭先預覽100ms才拍照; 照片大小：640x480; 將照片存入專案目錄下之photos子目錄
	command = 'sudo raspistill -t 100 -w 640 -h 480 -o ' + "./photos/" + picture_name;
	execSync(command);
	console.log('像片' + picture_name + '已經拍攝!');
	
	// 傳送警訊(含拍攝的照片)Email給主人
	// 讀取警訊接收者emails清單
	fs=require('fs');
	emails=fs.readFileSync('./alert-emails.txt','utf8');
	//
	subject = "入侵警示!";
	email_body = "警告：有人入侵(時間：" + datestring + ")，請看照片!";
	command = 'echo "' + email_body + '" | sudo mutt -s "' + subject + '" -a ' + "./photos/" + picture_name.toString() + ' -- ' + emails;
	exec = require('child_process').exec;
	exec(command);
	console.log("已經執行以下命令： " + command);
	console.log('已傳送告警Emails!');
	
	// 再次打開影像串流
	exec = require('child_process').exec;
	web_vs = exec('python3 ./web-vs-server.py', shell=false);
	wvs_pid = web_vs.pid+1;
	console.log('The current wvs_pid: ' + wvs_pid);
	// 將pid of Web Video Streaming存入檔案中
	fs = require('fs');
	fs.writeFileSync('./wvs-pid.txt', wvs_pid); 
	
	// 將on存入Web Video Streaming的狀態檔中
	fs = require('fs');
	fs.writeFileSync('./wvs-status.txt', 'on'); 
	console.log('The pid and status of web video streaming is saved!');
	
	// 回傳訊息給網頁端
	message={'message':'已經拍照並傳送警訊電郵!'};
	res.set({
		'charset': 'utf-8'  // 設定回傳結果之編碼為utf-8，網頁端才能正常顯示中文
	});
    res.send(message);

});

//******************************* 控制LED燈之服務方法 ***************************************
//********* 客戶端提出 POST /control8leds/:cmd 請求時，執行此服務方法(匿名式函數) *************
// 宣告全域變數：
// cmdflag用以紀錄命令是否有效 (本範例只有4個有效命令 "1"，"2"，"3"，"4")，初始設為1，代表有效命令
// lock用以紀錄目前操控按鈕是否已被鎖住，初始設為0，代表沒有鎖住
var cmdflag=1, lock=0;  
var ps = require('python-shell'); //載入python-shell模組
router.post('/control8leds/:cmd', function(req, res){
	cmd=req.params.cmd;
	console.log("cmd= " + cmd);

	cmdflag = 1;  // 初始設為1，代表有效命令 
	if(cmd=="1" && lock==0) 
		message = {"message":"奇偶數LED燈正在閃爍!"};
	else if (cmd=="2"  && lock==0) 
		message = {"message":"偶數LED燈正在閃爍!"};
	else if(cmd=="3"  && lock==0) 
		message = {"message":"正用PWM驅動LED燈! 頻率從左到右分別為10Hz, 20Hz...80Hz"};
	else if (cmd=="4"  && lock==0)
		message = {"message":"LED正在執行跑馬燈! 偶數燈先執行一次，再換基數燈執行一次"}; 
	else if (lock==0)
	{
		cmdflag = 0;
		message = {"message":"無效的命令!"};
	}
	else {}

	res.set({
	  'charset': 'utf-8'  // 設定回傳結果之編碼為utf-8，網頁端才能正常顯示中文
	});
	res.send(message);    // 將JSON格式訊息回傳給前端網頁
	
	if(cmdflag == 1 && lock==0)
	{
		lock = 1; // 鎖住控制按鈕 
		var options = {
					pythonOptions: ['-u'], // get print results in real-time
					mode: 'text',
					args: [cmd]
				};
			
		ps.PythonShell.run('./control-leds.py', options, function(err, results){
				if (err) 
					console.log( "Python回傳錯誤訊息" + err);
				else
				{
					// 將JSON格式字串轉換成JSON物件
					results = JSON.parse(results);
					// 列印出Python程式control-leds.py回傳的訊息
					console.log(results.message);
				}
				lock = 0; // 解鎖控制按鈕 
		});
	}
});

//********************************* 讀取DHT22之服務方法 **************************************
//************* 客戶端提出 POST /readDHT22 請求時，執行此服務方法(匿名式函數) ******************
var dhtsensor = require('node-dht-sensor'); // 引用node-dht-sensor套件
router.post('/readDHT22', function(req, res){
	//初始化dhtsensor物件，22 代表 DHT22, 12 代表 GPIO12 
	dhtsensor.initialize(22, 12);  
	// 讀取DHT22感測值  
	var readout = dhtsensor.read();  
	// 讀取溫度值，取到小數點1位
	temperature = readout.temperature.toFixed(1); 
	console.log("temperature= " + temperature);
	// 讀取濕度值，取到小數點1位
	humidity = readout.humidity.toFixed(1);
	console.log("humidity= " + humidity);
	// 將溫、溼度值打包成JSON物件
	result = {"temperature":temperature, "humidity":humidity};

	// 設定回傳結果之編碼為utf-8，網頁端才能正常顯示中文
	res.set({
	  'charset': 'utf-8'  
	});
	// 將JSON物件回傳給前端網頁
	res.send(result);    
});

module.exports = router;