package com.example.a6409001_app_finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class GuidePage extends AppCompatActivity implements View.OnClickListener{

    Button chinese, western;
    Intent activityC, activityW;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide_page);

        chinese=findViewById(R.id.chinese);
        chinese.setOnClickListener(this);
        western=findViewById(R.id.western);
        western.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        activityC =new Intent(this,MainActivity.class );
        activityW =new Intent(this,Main2Activity.class );
        startActivity((v.getId()==R.id.chinese)? activityC:activityW);
    }
}
