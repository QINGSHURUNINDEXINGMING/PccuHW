// 引用express模組 
var express = require('express');
// 使用express.Router類別建構子來建立路由物件
var router = express.Router();
// 引用request模組，用於呼叫Web API
var request = require('request');
// 引用fs模組，用於讀取檔案
var fs = require('fs'); // 
// 全域變數
var photofilename;

// 建立Web Video Streaming的狀態儲存檔wvs_status.txt(初始值為off)
fs.writeFileSync('./wvs-status.txt', 'off');
console.log('The wvs-status.txt is created!');

// 建立Web Video Streaming的pid儲存檔wvs_pid.txt(初始值為0)
fs.writeFileSync('./wvs-pid.txt', '0');
console.log('The wvs-pid.txt is created!');

// 取得並列出Server端的ip，需在專案中安裝underscore模組: npm install underscore --save
var serverip = require('underscore').chain(require('os').networkInterfaces()).values()
    .flatten().find({family: 'IPv4', internal: false}).value().address;
console.log('Server IP=' + serverip);

//========****** 根據Client端利用GET送來之不同路由，回傳相對應的網頁 ********========
// 回傳給Client端首頁及該網頁之標題
router.get('/', function(req, res) {
	res.render('index.ejs', {title:"專案首頁"});
});

// 回傳給Client拍照與辨識影像操作網頁及該網頁之標題
router.get('/photo-recognizephoto', function(req, res) {
	// 讓遠端監控網頁載入時，就顯示影像串流
	// 讀取Web Video Streaming的狀態
	wvs_status = fs.readFileSync('./wvs-status.txt','utf8'); 
	
	// 若影像串流關閉著，則啟動影像串流
	if(wvs_status=='off')
	{
		exec = require('child_process').exec;
		web_vs = exec('python3 ./web-vs-server.py', shell=false);
		wvs_pid = web_vs.pid+1;
		console.log('The current wvs_pid: ' + wvs_pid);
		
		// 將pid of Web Video Streaming存入檔案中
		fs = require('fs');
		fs.writeFileSync('./wvs-pid.txt', wvs_pid); 
		
		// 將on存入Web Video Streaming的狀態檔中
		fs = require('fs');
		fs.writeFileSync('./wvs-status.txt', 'on'); 
		console.log('The pid and status of web video streaming is saved!');
	}
	// 將拍照與辨識照片操作網頁與其標題及伺服器端IP傳送到前端
	res.render('photo-recognizephoto.ejs', {title:"拍照與辨識照片操作網頁", serverip: serverip});
});

//=================== 以下為REST網路服務段落 ==================================//
//==== 根據Client端利用GET或POST送來之不同路由，執行相對應之服務方法 ==========//
//===================================================================+++====//

//******************** 啟動與關閉即時網頁視訊串流之服務方法 *****************************
//***** 客戶端提出 POST /web_video_streaming/:cmd 請求時，執行此服務方法(匿名式函數) *****
router.post('/web_video_streaming/:cmd', function(req, res){
	cmd=req.params.cmd;
	if(cmd=='on')
	{
		// 讀取Web Video Streaming的狀態
		fs=require('fs');
		wvs_status = fs.readFileSync('./wvs-status.txt','utf8'); 
		
		//
		if(wvs_status=='off')
		{
			exec = require('child_process').exec;
			web_vs = exec('python3 ./web-vs-server.py', shell=false);
			wvs_pid = web_vs.pid+1;
			console.log('The current wvs_pid: '+ wvs_pid);
			
			// 將pid of Web Video Streaming存入檔案中
			fs = require('fs');
			fs.writeFileSync('./wvs-pid.txt', wvs_pid); 
			
			// 將on存入Web Video Streaming的狀態檔中
			fs = require('fs');
			fs.writeFileSync('./wvs-status.txt', 'on'); 
			console.log('The pid and status of web video streaming is saved!');
		}
		// 回傳訊息給網頁端
		message={'message':'網頁即時影像串流已經開啟!'};
		res.set({
			'charset': 'utf-8'  // 設定回傳結果之編碼為utf-8，網頁端才能正常顯示中文
		});
		res.send(message);
	}

	if(cmd=='off') 
	{
		// 讀取Web Video Streaming的狀態
		fs=require('fs');
		wvs_status=fs.readFileSync('./wvs-status.txt','utf8');
		
		//
		if(wvs_status=='on')
		{
			// 讀取pid of Web Video Streaming
			fs=require('fs');
			wvs_pid=fs.readFileSync('./wvs-pid.txt','utf8');
			
			// 透過pid關閉(殺掉)Web Video Streaming
			exec = require('child_process').exec;
			exec('sudo kill ' + wvs_pid);
			console.log('The wvs process of ' + wvs_pid + ' is killed!');
			
			// 將off存入Web Video Streaming的狀態檔中
			fs = require('fs');
			fs.writeFileSync('./wvs-status.txt', 'off');
		}
			
		// 回傳訊息給網頁端
		message={'message':'網頁即時影像串流已經關閉!'};
		res.set({
			'charset': 'utf-8'  // 設定回傳結果之編碼為utf-8，網頁端才能正常顯示中文
		});
		res.send(message);
	}
});

//******************** 拍照與辨識照片(呼叫ACV-API)之服務方法 *****************************
//***** 客戶端提出 POST /photo-recognizephoto 請求時，執行此服務方法(匿名式函數) *****
router.post("/photo-recognizephoto", function (req, res) {
	// 讀取Web Video Streaming的狀態
	fs=require('fs');
	wvs_status=fs.readFileSync('./wvs-status.txt','utf8');
	
	// 若網路視訊串流開著，先把它關掉
	if(wvs_status=='on')
	{
		// 讀取pid of Web Video Streaming
		fs=require('fs');
		wvs_pid=fs.readFileSync('./wvs-pid.txt','utf8');
		
		// 透過pid關閉(殺掉)Web Video Streaming
		exec = require('child_process').exec;
		exec('sudo kill ' + wvs_pid);
		console.log('The wvs process of ' + wvs_pid + ' is killed!');
		// 將off存入Web Video Streaming的狀態檔中
		fs = require('fs');
		fs.writeFileSync('./wvs-status.txt', 'off');
	}
	
	// 設定拍照取得的照片名稱
	photofilename = 'sourcephoto.jpg'; 
	// 開始拍照 (使用同步方式執行，以確保在辨識照片之前就有照片了)
	execSync = require('child_process').execSync;
	// 命令解讀： 攝像頭先預覽200ms才拍照; 照片大小：640x480; 將照片存入專案目錄下public資料夾之photos子目錄
	command = 'sudo raspistill -t 200 -w 640 -h 480 -o ' + "./public/photos/" + photofilename;
	execSync(command);
	console.log('照片' + photofilename + '已經拍攝!');

	// 再次打開網路視訊串流
	exec = require('child_process').exec;
	web_vs = exec('python3 ./web-vs-server.py', shell=false);
	wvs_pid = web_vs.pid+1;
	console.log('The current wvs_pid: ' + wvs_pid);
	// 將pid of Web Video Streaming存入檔案中
	fs = require('fs');
	fs.writeFileSync('./wvs-pid.txt', wvs_pid); 
	
	// 將on存入Web Video Streaming的狀態檔中
	fs = require('fs');
	fs.writeFileSync('./wvs-status.txt', 'on'); 
	console.log('The pid and status of web video streaming is saved!');
	
	// 讀取來源照片檔成為位元組流(陣列)(octet stream);
	var imgoctet = fs.readFileSync('./public/photos/' +  photofilename);

	// 分析照片API之選項設定
	var apioptions_analyze = {
		url: 'https://eastasia.api.cognitive.microsoft.com/vision/v2.1/analyze',
		qs: {
			visualFeatures: 'Categories,Description,Objects,Faces',
			details: '',
			language: 'en'
		},
		headers: {
			'Content-Type' : 'application/octet-stream', 
			'Ocp-Apim-Subscription-Key': '17e8f18940294dd395ba552a9e5e9a58'
		},
		body: imgoctet,
		method: 'POST'
	};

	request(apioptions_analyze, function(error, response, body){
		if (error){
			console.log(error);
			// 將分析結果訊息打包成JSON物件
			message = {"status": 1, 'result': error, 'photourl': '/photos/' +  photofilename};
			// 設定回傳結果之編碼為utf-8，網頁端才能正常顯示中文
			res.set({
				'charset': 'utf-8'  
			});
			// 以JSON格式回傳訊息與照片之URL給前端網頁
			res.json(message);
		}
		else {
			// 將回傳的結果JSON字串轉換成JSON物件
			resultobj = JSON.parse(body);
			// 在終端機中以階層格式印出結果JSON物件
			console.log("分析結果：");
			console.dir(resultobj);
			// 將分析結果訊息打包成JSON物件
			message = {"status": 0, 'result': resultobj, 'photourl': '/photos/' +  photofilename};
			// 設定回傳結果之編碼為utf-8，網頁端才能正常顯示中文
			res.set({
				'charset': 'utf-8'  
			});
			// 以JSON格式回傳訊息與照片之URL給前端網頁
			res.json(message);
		}
	});

});

module.exports = router;